
import React from 'react';
import {
  View,
} from 'react-native';

import Header from './Header';

export default () => {

    return (
        <View>
            <Header />
        </View>
    );
}