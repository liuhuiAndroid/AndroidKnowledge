declare namespace Info {

    type Dog = {
        name: string;
        age: number;
        weight: number;
    }
}